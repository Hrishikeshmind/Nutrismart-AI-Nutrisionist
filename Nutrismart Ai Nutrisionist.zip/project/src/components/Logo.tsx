import React from 'react';
import { Leaf } from 'lucide-react';

export const Logo = () => {
  return (
    <div className="flex items-center gap-2">
      <div className="relative">
        <Leaf className="w-10 h-10 text-green-600 transform -rotate-45" />
        <div className="absolute -top-1 -right-1">
          <div className="w-4 h-4 bg-green-400 rounded-full animate-pulse" />
        </div>
      </div>
      <span className="text-3xl font-bold">
        Nutri<span className="text-green-600">Smart</span>
      </span>
    </div>
  );
};