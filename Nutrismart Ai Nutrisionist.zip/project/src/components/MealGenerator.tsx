import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { ChefHat, Loader2, UtensilsCrossed, Apple, Salad, Clock, Tag, Filter, Activity, Scale, Heart } from 'lucide-react';
import OpenAI from 'openai';

interface HealthProfile {
  age?: number;
  weight?: number;
  height?: number;
  activityLevel?: string;
  healthGoals?: string[];
  medicalConditions?: string[];
}

interface NutritionalAdvice {
  dailyCalories: string;
  macroBreakdown: {
    protein: string;
    carbs: string;
    fats: string;
  };
  recommendations: string[];
  warnings: string[];
}

interface Meal {
  name: string;
  description: string;
  cookingTime: string;
  difficulty: string;
  cuisine: string;
  ingredients: string[];
  instructions: string[];
  nutritionalInfo: {
    calories: string;
    protein: string;
    carbs: string;
    fats: string;
    fiber: string;
    vitamins: string[];
  };
  tags: string[];
  healthBenefits: string[];
}

export const MealGenerator = () => {
  const [preferences, setPreferences] = useState('');
  const [dietaryRestrictions, setDietaryRestrictions] = useState<string[]>([]);
  const [cookingTime, setCookingTime] = useState('any');
  const [cuisine, setCuisine] = useState('any');
  const [loading, setLoading] = useState(false);
  const [meal, setMeal] = useState<Meal | null>(null);
  const [error, setError] = useState('');
  const [healthProfile, setHealthProfile] = useState<HealthProfile>({});
  const [showHealthProfile, setShowHealthProfile] = useState(false);
  const [nutritionalAdvice, setNutritionalAdvice] = useState<NutritionalAdvice | null>(null);

  const healthGoals = [
    'Weight Loss',
    'Muscle Gain',
    'Maintenance',
    'Better Sleep',
    'More Energy',
    'Heart Health',
    'Blood Sugar Control'
  ];

  const activityLevels = [
    'Sedentary',
    'Lightly Active',
    'Moderately Active',
    'Very Active',
    'Extremely Active'
  ];

  const medicalConditions = [
    'Diabetes',
    'Hypertension',
    'High Cholesterol',
    'Celiac Disease',
    'Food Allergies',
    'None'
  ];

  const dietaryOptions = [
    'Vegetarian', 'Vegan', 'Gluten-Free', 'Dairy-Free',
    'Keto', 'Paleo', 'Low-Carb', 'Low-Fat'
  ];

  const cuisineOptions = [
    'any', 'Italian', 'Asian', 'Mexican', 'Mediterranean',
    'Indian', 'American', 'French', 'Middle Eastern'
  ];

  const timeOptions = [
    { value: 'any', label: 'Any Time' },
    { value: '15', label: '15 minutes' },
    { value: '30', label: '30 minutes' },
    { value: '45', label: '45 minutes' },
    { value: '60', label: '1 hour' }
  ];

  const toggleDietaryRestriction = (restriction: string) => {
    setDietaryRestrictions(prev =>
      prev.includes(restriction)
        ? prev.filter(r => r !== restriction)
        : [...prev, restriction]
    );
  };

  const toggleHealthGoal = (goal: string) => {
    setHealthProfile(prev => ({
      ...prev,
      healthGoals: prev.healthGoals?.includes(goal)
        ? prev.healthGoals.filter(g => g !== goal)
        : [...(prev.healthGoals || []), goal]
    }));
  };

  const toggleMedicalCondition = (condition: string) => {
    setHealthProfile(prev => ({
      ...prev,
      medicalConditions: prev.medicalConditions?.includes(condition)
        ? prev.medicalConditions.filter(c => c !== condition)
        : [...(prev.medicalConditions || []), condition]
    }));
  };

  const generateNutritionalAdvice = async () => {
    try {
      const openai = new OpenAI({
        apiKey: import.meta.env.VITE_OPENAI_API_KEY,
        dangerouslyAllowBrowser: true
      });

      const response = await openai.chat.completions.create({
        model: "gpt-4",
        messages: [{
          role: "user",
          content: `Based on this health profile:
            Age: ${healthProfile.age}
            Weight: ${healthProfile.weight}kg
            Height: ${healthProfile.height}cm
            Activity Level: ${healthProfile.activityLevel}
            Health Goals: ${healthProfile.healthGoals?.join(', ')}
            Medical Conditions: ${healthProfile.medicalConditions?.join(', ')}

            Provide nutritional advice in this JSON format:
            {
              "dailyCalories": "amount",
              "macroBreakdown": {
                "protein": "amount in g",
                "carbs": "amount in g",
                "fats": "amount in g"
              },
              "recommendations": ["rec1", "rec2"],
              "warnings": ["warning1", "warning2"]
            }`
        }],
        temperature: 0.7
      });

      const advice = JSON.parse(response.choices[0].message.content || '');
      setNutritionalAdvice(advice);
    } catch (err) {
      console.error(err);
      setError('Failed to generate nutritional advice');
    }
  };

  const generateMeal = async () => {
    setLoading(true);
    setError('');
    
    try {
      const openai = new OpenAI({
        apiKey: import.meta.env.VITE_OPENAI_API_KEY,
        dangerouslyAllowBrowser: true
      });

      const prompt = `Generate a healthy meal recipe with these specifications:
        Health Profile:
        - Goals: ${healthProfile.healthGoals?.join(', ')}
        - Medical Conditions: ${healthProfile.medicalConditions?.join(', ')}
        - Activity Level: ${healthProfile.activityLevel}
        
        Preferences: ${preferences}
        Dietary Restrictions: ${dietaryRestrictions.join(', ')}
        Cooking Time: ${cookingTime}
        Cuisine: ${cuisine}
        
        Return it in this JSON format: {
          "name": "meal name",
          "description": "brief description",
          "cookingTime": "time in minutes",
          "difficulty": "easy/medium/hard",
          "cuisine": "cuisine type",
          "ingredients": ["ingredient1", "ingredient2"],
          "instructions": ["step1", "step2"],
          "nutritionalInfo": {
            "calories": "amount",
            "protein": "amount",
            "carbs": "amount",
            "fats": "amount",
            "fiber": "amount",
            "vitamins": ["vitamin1", "vitamin2"]
          },
          "tags": ["tag1", "tag2"],
          "healthBenefits": ["benefit1", "benefit2"]
        }`;

      const response = await openai.chat.completions.create({
        model: "gpt-4",
        messages: [{ role: "user", content: prompt }],
        temperature: 0.7
      });

      const mealData = JSON.parse(response.choices[0].message.content || '');
      setMeal(mealData);
    } catch (err) {
      setError('Failed to generate meal. Please try again.');
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  return (
    <section className="py-20 bg-gradient-to-b from-green-50 to-white">
      <div className="container mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <ChefHat className="w-16 h-16 mx-auto text-green-600 mb-4" />
          <h2 className="text-4xl font-bold text-gray-900 mb-4">
            AI Health & Nutrition Advisor
          </h2>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            Get personalized meal plans and health advice tailored to your unique profile
          </p>
        </motion.div>

        <div className="max-w-4xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="bg-white p-8 rounded-2xl shadow-xl mb-8"
          >
            <div className="flex justify-between items-center mb-6">
              <h3 className="text-2xl font-bold text-gray-900">Health Profile</h3>
              <button
                onClick={() => setShowHealthProfile(!showHealthProfile)}
                className="text-green-600 hover:text-green-700"
              >
                {showHealthProfile ? 'Hide' : 'Show'} Profile
              </button>
            </div>

            {showHealthProfile && (
              <div className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div>
                    <label className="block text-gray-700 text-sm font-medium mb-2">
                      Age
                    </label>
                    <input
                      type="number"
                      value={healthProfile.age || ''}
                      onChange={(e) => setHealthProfile(prev => ({
                        ...prev,
                        age: parseInt(e.target.value)
                      }))}
                      className="w-full px-4 py-2 rounded-lg border border-gray-300 focus:ring-2 focus:ring-green-500 focus:border-transparent"
                    />
                  </div>
                  <div>
                    <label className="block text-gray-700 text-sm font-medium mb-2">
                      Weight (kg)
                    </label>
                    <input
                      type="number"
                      value={healthProfile.weight || ''}
                      onChange={(e) => setHealthProfile(prev => ({
                        ...prev,
                        weight: parseInt(e.target.value)
                      }))}
                      className="w-full px-4 py-2 rounded-lg border border-gray-300 focus:ring-2 focus:ring-green-500 focus:border-transparent"
                    />
                  </div>
                  <div>
                    <label className="block text-gray-700 text-sm font-medium mb-2">
                      Height (cm)
                    </label>
                    <input
                      type="number"
                      value={healthProfile.height || ''}
                      onChange={(e) => setHealthProfile(prev => ({
                        ...prev,
                        height: parseInt(e.target.value)
                      }))}
                      className="w-full px-4 py-2 rounded-lg border border-gray-300 focus:ring-2 focus:ring-green-500 focus:border-transparent"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-gray-700 text-sm font-medium mb-2">
                    Activity Level
                  </label>
                  <select
                    value={healthProfile.activityLevel || ''}
                    onChange={(e) => setHealthProfile(prev => ({
                      ...prev,
                      activityLevel: e.target.value
                    }))}
                    className="w-full px-4 py-2 rounded-lg border border-gray-300 focus:ring-2 focus:ring-green-500 focus:border-transparent"
                  >
                    <option value="">Select Activity Level</option>
                    {activityLevels.map(level => (
                      <option key={level} value={level}>{level}</option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-gray-700 text-sm font-medium mb-2">
                    Health Goals
                  </label>
                  <div className="flex flex-wrap gap-2">
                    {healthGoals.map(goal => (
                      <button
                        key={goal}
                        onClick={() => toggleHealthGoal(goal)}
                        className={`px-3 py-1 rounded-full text-sm font-medium transition-colors ${
                          healthProfile.healthGoals?.includes(goal)
                            ? 'bg-green-600 text-white'
                            : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                        }`}
                      >
                        {goal}
                      </button>
                    ))}
                  </div>
                </div>

                <div>
                  <label className="block text-gray-700 text-sm font-medium mb-2">
                    Medical Conditions
                  </label>
                  <div className="flex flex-wrap gap-2">
                    {medicalConditions.map(condition => (
                      <button
                        key={condition}
                        onClick={() => toggleMedicalCondition(condition)}
                        className={`px-3 py-1 rounded-full text-sm font-medium transition-colors ${
                          healthProfile.medicalConditions?.includes(condition)
                            ? 'bg-green-600 text-white'
                            : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                        }`}
                      >
                        {condition}
                      </button>
                    ))}
                  </div>
                </div>

                <motion.button
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                  onClick={generateNutritionalAdvice}
                  className="w-full bg-green-600 text-white py-3 rounded-lg font-semibold hover:bg-green-700 transition-colors"
                >
                  Get Nutritional Advice
                </motion.button>

                {nutritionalAdvice && (
                  <motion.div
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    className="mt-6 p-6 bg-green-50 rounded-xl"
                  >
                    <h4 className="text-xl font-semibold text-gray-900 mb-4">Your Personalized Nutrition Plan</h4>
                    
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
                      <div className="bg-white p-4 rounded-lg shadow">
                        <div className="flex items-center gap-2 text-green-600 mb-2">
                          <Activity className="w-5 h-5" />
                          <span className="font-medium">Daily Calories</span>
                        </div>
                        <p className="text-2xl font-bold">{nutritionalAdvice.dailyCalories}</p>
                      </div>
                      
                      <div className="bg-white p-4 rounded-lg shadow">
                        <div className="flex items-center gap-2 text-green-600 mb-2">
                          <Scale className="w-5 h-5" />
                          <span className="font-medium">Protein</span>
                        </div>
                        <p className="text-2xl font-bold">{nutritionalAdvice.macroBreakdown.protein}</p>
                      </div>
                      
                      <div className="bg-white p-4 rounded-lg shadow">
                        <div className="flex items-center gap-2 text-green-600 mb-2">
                          <Heart className="w-5 h-5" />
                          <span className="font-medium">Carbs</span>
                        </div>
                        <p className="text-2xl font-bold">{nutritionalAdvice.macroBreakdown.carbs}</p>
                      </div>
                    </div>

                    <div className="space-y-4">
                      <div>
                        <h5 className="font-semibold text-gray-900 mb-2">Recommendations</h5>
                        <ul className="list-disc list-inside space-y-1">
                          {nutritionalAdvice.recommendations.map((rec, index) => (
                            <li key={index} className="text-gray-600">{rec}</li>
                          ))}
                        </ul>
                      </div>

                      {nutritionalAdvice.warnings.length > 0 && (
                        <div>
                          <h5 className="font-semibold text-gray-900 mb-2">Important Notes</h5>
                          <ul className="list-disc list-inside space-y-1">
                            {nutritionalAdvice.warnings.map((warning, index) => (
                              <li key={index} className="text-red-600">{warning}</li>
                            ))}
                          </ul>
                        </div>
                      )}
                    </div>
                  </motion.div>
                )}
              </div>
            )}
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="bg-white p-8 rounded-2xl shadow-xl"
          >
            <h3 className="text-2xl font-bold text-gray-900 mb-6">Generate Your Meal</h3>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
              <div>
                <label className="block text-gray-700 text-sm font-medium mb-2">
                  Preferences
                </label>
                <textarea
                  value={preferences}
                  onChange={(e) => setPreferences(e.target.value)}
                  placeholder="E.g., high-protein, low-carb..."
                  className="w-full px-4 py-3 rounded-lg border border-gray-300 focus:ring-2 focus:ring-green-500 focus:border-transparent"
                  rows={3}
                />
              </div>

              <div>
                <label className="block text-gray-700 text-sm font-medium mb-2">
                  Dietary Restrictions
                </label>
                <div className="flex flex-wrap gap-2">
                  {dietaryOptions.map((option) => (
                    <button
                      key={option}
                      onClick={() => toggleDietaryRestriction(option)}
                      className={`px-3 py-1 rounded-full text-sm font-medium transition-colors ${
                        dietaryRestrictions.includes(option)
                          ? 'bg-green-600 text-white'
                          : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                      }`}
                    >
                      {option}
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <label className="block text-gray-700 text-sm font-medium mb-2">
                  Cooking Time
                </label>
                <select
                  value={cookingTime}
                  onChange={(e) => setCookingTime(e.target.value)}
                  className="w-full px-4 py-3 rounded-lg border border-gray-300 focus:ring-2 focus:ring-green-500 focus:border-transparent"
                >
                  {timeOptions.map((option) => (
                    <option key={option.value} value={option.value}>
                      {option.label}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-gray-700 text-sm font-medium mb-2">
                  Cuisine Type
                </label>
                <select
                  value={cuisine}
                  onChange={(e) => setCuisine(e.target.value)}
                  className="w-full px-4 py-3 rounded-lg border border-gray-300 focus:ring-2 focus:ring-green-500 focus:border-transparent"
                >
                  {cuisineOptions.map((option) => (
                    <option key={option} value={option}>
                      {option.charAt(0).toUpperCase() + option.slice(1)}
                    </option>
                  ))}
                </select>
              </div>
            </div>

            <motion.button
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
              onClick={generateMeal}
              disabled={loading || !preferences}
              className="w-full bg-green-600 text-white py-3 rounded-lg font-semibold hover:bg-green-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {loading ? (
                <span className="flex items-center justify-center">
                  <Loader2 className="w-5 h-5 animate-spin mr-2" />
                  Generating...
                </span>
              ) : (
                'Generate Personalized Meal'
              )}
            </motion.button>

            {error && (
              <p className="mt-4 text-red-500 text-center">{error}</p>
            )}

            {meal && (
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className="mt-8"
              >
                <div className="mb-6">
                  <h3 className="text-2xl font-bold text-gray-900 mb-2 flex items-center">
                    <UtensilsCrossed className="w-6 h-6 mr-2 text-green-600" />
                    {meal.name}
                  </h3>
                  <p className="text-gray-600">{meal.description}</p>
                  
                  <div className="flex flex-wrap gap-4 mt-4">
                    <div className="flex items-center text-gray-600">
                      <Clock className="w-4 h-4 mr-1" />
                      {meal.cookingTime}
                    </div>
                    <div className="flex items-center text-gray-600">
                      <Tag className="w-4 h-4 mr-1" />
                      {meal.difficulty}
                    </div>
                    <div className="flex items-center text-gray-600">
                      <Filter className="w-4 h-4 mr-1" />
                      {meal.cuisine}
                    </div>
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-6">
                  <div>
                    <h4 className="font-semibold text-gray-900 mb-3 flex items-center">
                      <Apple className="w-5 h-5 mr-2 text-green-600" />
                      Ingredients
                    </h4>
                    <ul className="list-disc list-inside space-y-2">
                      {meal.ingredients.map((ingredient, index) => (
                        <li key={index} className="text-gray-600">{ingredient}</li>
                      ))}
                    </ul>
                  </div>

                  <div>
                    <h4 className="font-semibold text-gray-900 mb-3 flex items-center">
                      <Salad className="w-5 h-5 mr-2 text-green-600" />
                      Nutritional Info
                    </h4>
                    <div className="grid grid-cols-2 gap-4">
                      <div className="bg-green-50 p-3 rounded-lg">
                        <p className="text-sm text-gray-600">Calories</p>
                        <p className="font-semibold">{meal.nutritionalInfo.calories}</p>
                      </div>
                      <div className="bg-green-50 p-3 rounded-lg">
                        <p className="text-sm text-gray-600">Protein</p>
                        <p className="font-semibold">{meal.nutritionalInfo.protein}</p>
                      </div>
                      <div className="bg-green-50 p-3 rounded-lg">
                        <p className="text-sm text-gray-600">Carbs</p>
                        <p className="font-semibold">{meal.nutritionalInfo.carbs}</p>
                      </div>
                      <div className="bg-green-50 p-3 rounded-lg">
                        <p className="text-sm text-gray-600">Fats</p>
                        <p className="font-semibold">{meal.nutritionalInfo.fats}</p>
                      </div>
                    </div>

                    <div className="mt-4">
                      <h5 className="font-semibold text-gray-900 mb-2">Key Vitamins & Minerals</h5>
                      <div className="flex flex-wrap gap-2">
                        {meal.nutritionalInfo.vitamins.map((vitamin, index) => (
                          <span key={index} className="px-2 py-1 bg-green-100 text-green-800 rounded-full text-sm">
                            {vitamin}
                          </span>
                        ))}
                      </div>
                    </div>
                  </div>
                </div>

                <div>
                  <h4 className="font-semibold text-gray-900 mb-3">Instructions</h4>
                  <ol className="list-decimal list-inside space-y-2">
                    {meal.instructions.map((step, index) => (
                      <li key={index} className="text-gray-600">{step}</li>
                    ))}
                  </ol>
                </div>

                <div className="mt-6">
                  <h4 className="font-semibold text-gray-900 mb-2">Health Benefits</h4>
                  <div className="flex flex-wrap gap-2">
                    {meal.healthBenefits.map((benefit, index) => (
                      <span key={index} className="px-3 py-1 bg-green-100 text-green-700 rounded-full text-sm">
                        {benefit}
                      </span>
                    ))}
                  </div>
                </div>

                <div className="mt-6">
                  <h4 className="font-semibold text-gray-900 mb-2">Tags</h4>
                  <div className="flex flex-wrap gap-2">
                    {meal.tags.map((tag, index) => (
                      <span key={index} className="px-3 py-1 bg-gray-100 text-gray-700 rounded-full text-sm">
                        #{tag}
                      </span>
                    ))}
                  </div>
                </div>
              </motion.div>
            )}
          </motion.div>
        </div>
      </div>
    </section>
  );
};