import React from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Hero } from './components/Hero';
import { Features } from './components/Features';
import { MealGenerator } from './components/MealGenerator';
import { Pricing } from './components/Pricing';

function App() {
  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        className="bg-white"
      >
        <Hero />
        <Features />
        <MealGenerator />
        <Pricing />
      </motion.div>
    </AnimatePresence>
  );
}

export default App;