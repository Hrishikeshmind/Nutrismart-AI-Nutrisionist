import React from 'react';
import { motion } from 'framer-motion';
import { Utensils, Brain, Heart, Sparkles, Apple, Activity, Scale } from 'lucide-react';

const features = [
  {
    icon: <Brain className="w-8 h-8" />,
    title: 'AI Health Advisor',
    description: 'Get personalized health recommendations and nutritional guidance from our advanced AI system.'
  },
  {
    icon: <Scale className="w-8 h-8" />,
    title: 'Personalized Meal Plans',
    description: 'Receive custom meal plans based on your health profile, goals, and dietary preferences.'
  },
  {
    icon: <Heart className="w-8 h-8" />,
    title: 'Health Monitoring',
    description: 'Track your nutritional intake, health metrics, and progress towards your wellness goals.'
  },
  {
    icon: <Activity className="w-8 h-8" />,
    title: 'Lifestyle Integration',
    description: 'Get advice that fits your activity level and daily routine for sustainable results.'
  },
  {
    icon: <Apple className="w-8 h-8" />,
    title: 'Nutritional Analysis',
    description: 'Detailed breakdown of nutrients and health benefits for every meal recommendation.'
  },
  {
    icon: <Sparkles className="w-8 h-8" />,
    title: 'Smart Recommendations',
    description: 'AI-powered suggestions that adapt to your changing health needs and preferences.'
  }
];

export const Features = () => {
  return (
    <section className="py-20 bg-white">
      <div className="container mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <h2 className="text-4xl font-bold text-gray-900 mb-4">
            Your Personal AI Health Assistant
          </h2>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            Experience comprehensive health and nutrition guidance powered by advanced AI
          </p>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {features.map((feature, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: index * 0.1 }}
              whileHover={{ y: -5 }}
              className="bg-green-50 p-6 rounded-xl hover:shadow-xl transition-shadow"
            >
              <div className="text-green-600 mb-4">{feature.icon}</div>
              <h3 className="text-xl font-semibold text-gray-900 mb-2">
                {feature.title}
              </h3>
              <p className="text-gray-600">{feature.description}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};