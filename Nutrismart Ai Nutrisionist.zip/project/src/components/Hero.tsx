import React from 'react';
import { motion } from 'framer-motion';
import { Sparkles, Apple, Brain } from 'lucide-react';

export const Hero = () => {
  return (
    <div className="relative min-h-screen bg-gradient-to-b from-green-50 to-green-100 overflow-hidden">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.8 }}
        className="container mx-auto px-4 pt-32 pb-16 text-center"
      >
        <motion.div
          initial={{ scale: 0.8 }}
          animate={{ scale: 1 }}
          transition={{ duration: 0.5 }}
          className="absolute top-20 right-20 text-green-500"
        >
          <Sparkles size={40} className="animate-pulse" />
        </motion.div>

        <h1 className="text-6xl font-bold text-gray-900 mb-6">
          NutriSmart
          <span className="text-green-600">AI</span>
        </h1>
        <p className="text-xl text-gray-700 mb-8 max-w-2xl mx-auto">
          Your personal AI-powered nutrition planner that creates perfect meal plans tailored to your goals
        </p>

        <div className="flex justify-center gap-6 mb-12">
          <motion.button
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            className="px-8 py-4 bg-green-600 text-white rounded-full font-semibold shadow-lg hover:bg-green-700 transition-colors"
          >
            Get Started Free
          </motion.button>
          <motion.button
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            className="px-8 py-4 bg-white text-green-600 rounded-full font-semibold shadow-lg hover:bg-gray-50 transition-colors"
          >
            Learn More
          </motion.button>
        </div>

        <motion.div 
          initial={{ y: 100, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ duration: 0.8, delay: 0.2 }}
          className="relative"
        >
          <img
            src="https://images.unsplash.com/photo-1543362906-acfc16c67564?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80"
            alt="Healthy food spread"
            className="rounded-xl shadow-2xl mx-auto max-w-4xl"
          />
          <div className="absolute -bottom-6 left-1/2 transform -translate-x-1/2 flex gap-4">
            <motion.div
              whileHover={{ y: -5 }}
              className="bg-white p-4 rounded-xl shadow-lg"
            >
              <Apple className="text-green-500 w-8 h-8" />
            </motion.div>
            <motion.div
              whileHover={{ y: -5 }}
              className="bg-white p-4 rounded-xl shadow-lg"
            >
              <Brain className="text-green-500 w-8 h-8" />
            </motion.div>
          </div>
        </motion.div>
      </motion.div>
    </div>
  );
};